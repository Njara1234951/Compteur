package com.example.compteur

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: return
        Alarms.remove(ctx, id)
        Alarms.notify(
            ctx,
            id,
            intent.getStringExtra("titre") ?: "Compteur de jours",
            intent.getStringExtra("texte") ?: "",
            intent.getBooleanExtra("son", true),
            intent.getBooleanExtra("vib", true)
        )
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) Alarms.reschedule(ctx)
    }
}
