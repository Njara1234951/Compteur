package com.example.compteur

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/**
 * Alarmes natives : elles sonnent même si l'application est fermée.
 * La page envoie la liste complète des alarmes à chaque changement (sync).
 */
object Alarms {
    private const val PREFS = "alarms"
    private const val KEY = "list"

    private fun intentFor(ctx: Context, id: String) =
        Intent(ctx, AlarmReceiver::class.java)
            .setData(Uri.parse("alarm://$id"))
            .putExtra("id", id)

    private fun alarmManager(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun schedule(ctx: Context, a: JSONObject) {
        val id = a.getString("id")
        val intent = intentFor(ctx, id)
            .putExtra("titre", a.optString("titre"))
            .putExtra("texte", a.optString("texte"))
            .putExtra("son", a.optBoolean("son", true))
            .putExtra("vib", a.optBoolean("vib", true))
        val op = PendingIntent.getBroadcast(
            ctx, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        // setAlarmClock : exact, fonctionne en veille profonde, sans permission spéciale
        alarmManager(ctx).setAlarmClock(AlarmManager.AlarmClockInfo(a.getLong("at"), show), op)
    }

    private fun cancel(ctx: Context, id: String) {
        val op = PendingIntent.getBroadcast(
            ctx, 0, intentFor(ctx, id), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (op != null) {
            alarmManager(ctx).cancel(op)
            op.cancel()
        }
    }

    private fun stored(ctx: Context): JSONArray =
        try {
            JSONArray(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]"))
        } catch (e: Exception) {
            JSONArray()
        }

    private fun store(ctx: Context, list: JSONArray) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, list.toString()).apply()
    }

    @Synchronized
    fun sync(ctx: Context, json: String) {
        val old = stored(ctx)
        for (i in 0 until old.length()) cancel(ctx, old.getJSONObject(i).getString("id"))
        val now = System.currentTimeMillis()
        val keep = JSONArray()
        val list = JSONArray(json)
        for (i in 0 until list.length()) {
            val a = list.getJSONObject(i)
            if (a.getLong("at") > now) {
                schedule(ctx, a)
                keep.put(a)
            }
        }
        store(ctx, keep)
    }

    /** Après un redémarrage du téléphone, les alarmes système sont perdues : on les recrée. */
    @Synchronized
    fun reschedule(ctx: Context) {
        val list = stored(ctx)
        val now = System.currentTimeMillis()
        for (i in 0 until list.length()) {
            val a = list.getJSONObject(i)
            if (a.getLong("at") > now) schedule(ctx, a)
        }
    }

    @Synchronized
    fun remove(ctx: Context, id: String) {
        val list = stored(ctx)
        val keep = JSONArray()
        for (i in 0 until list.length()) {
            val a = list.getJSONObject(i)
            if (a.getString("id") != id) keep.put(a)
        }
        store(ctx, keep)
    }

    fun notify(ctx: Context, id: String, titre: String, texte: String, son: Boolean, vib: Boolean) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = when {
            son && vib -> "al_sv"
            son -> "al_s"
            else -> "al_v"
        }
        if (nm.getNotificationChannel(ch) == null) {
            val nom = when (ch) {
                "al_sv" -> "Alerte (son et vibration)"
                "al_s" -> "Alerte (son)"
                else -> "Alerte (vibration)"
            }
            val c = NotificationChannel(ch, nom, NotificationManager.IMPORTANCE_HIGH)
            if (son) {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                c.setSound(
                    uri,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            } else {
                c.setSound(null, null)
            }
            c.enableVibration(vib)
            if (vib) c.vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 500)
            nm.createNotificationChannel(c)
        }
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, ch)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(titre)
            .setContentText(texte)
            .setAutoCancel(true)
            .setContentIntent(open)
            .setCategory(Notification.CATEGORY_ALARM)
            .setTimeoutAfter(30000)
            .build()
        n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(id.hashCode(), n)
    }
}
