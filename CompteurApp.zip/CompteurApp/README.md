# Compteur de jours (Android)

Application qui affiche la page « Compteur de jours » dans une WebView (`app/src/main/assets/index.html`).

- Compteurs, couleurs, libellés et fond sont enregistrés sur le téléphone.
- Fond : 4 images fournies (`assets/bg`) ou une image de la galerie.
- Alertes : alarmes Android natives (`Alarms.kt`). Elles sonnent et vibrent même si l'application est fermée,
  et sont recréées après un redémarrage. Autorisez les notifications au premier lancement.

Compilation : onglet Actions de GitHub (workflow « Build APK »), ou Android Studio > Build APK(s).
